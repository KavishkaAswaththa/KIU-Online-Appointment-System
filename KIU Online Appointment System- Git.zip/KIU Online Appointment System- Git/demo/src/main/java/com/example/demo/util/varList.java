package com.example.demo.util;

public class varList {
    public static final String ASP_SUCCESS      = "00";
    public static final String ASP_NO_DATA_FOUND      = "01";
    public static final String ASP_NOT_AUTHORIZED      = "02";
    public static final String ASP_TOKEN_EXPIRED      = "03";
    public static final String ASP_TOKEN_INVALID      = "04";
    public static final String ASP_ERROR      = "05";
    public static final String ASP_DUPLICATED      = "06";
    public static final String ASP_FAIL      = "10";
}
